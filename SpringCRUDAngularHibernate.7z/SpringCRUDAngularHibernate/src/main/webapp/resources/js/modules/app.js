/**
 * "use strict";  Defines that JavaScript code should be executed in "strict mode".
 * With strict mode, you can not, use undeclared variables.
 */
'use strict';
var App = angular.module('myApp',[]);