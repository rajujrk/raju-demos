package com.raj.chat.room;

public enum MessageType {
	LOGIN, MESSAGE, TYPING
}
