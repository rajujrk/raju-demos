package com.raj.chat.room;

import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.logging.Logger;

import javax.websocket.CloseReason;
import javax.websocket.EndpointConfig;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import com.fasterxml.jackson.databind.ObjectMapper;

@ServerEndpoint(value = "/joinRoom")
public class ChatEndpoint {
	private Logger log = Logger.getLogger(ChatEndpoint.class.getSimpleName());
	private Room room = Room.getRoom();
	private static final Set<Room> connections = new CopyOnWriteArraySet<Room>();
	private Session session;

	@OnOpen
	public void open(final Session session, EndpointConfig config) {

		for (Session ses : session.getOpenSessions()) {
			System.out.println(ses);
		}

	}

	@OnMessage
	public void onMessage(final Session session, final String messageJson) {
		ObjectMapper mapper = new ObjectMapper();
		ChatMessage chatMessage = null;
		try {
			chatMessage = mapper.readValue(messageJson, ChatMessage.class);
		} catch (IOException e) {
			String message = "Badly formatted message";
			try {
				session.close(new CloseReason(CloseReason.CloseCodes.CANNOT_ACCEPT, message));
			} catch (IOException ex) {
				log.severe(ex.getMessage());
			}
		}
		;

		Map<String, Object> properties = session.getUserProperties();
		if (chatMessage.getMessageType() == MessageType.LOGIN) {
			String name = chatMessage.getMessage();
			properties.put("name", name);
			room.join(session);
			room.sendMessage(name + "^join^" + session.getId());
			this.session = session;
			connections.add(room);
			sendBroadcast();
		} else if(chatMessage.getMessageType().equals(MessageType.MESSAGE)) {
			//String name = (String) properties.get("name");
			//room.sendMessage(name + " - " + chatMessage.getMessage());
			String strMsg = chatMessage.getMessage();
			String strFrom = chatMessage.getFromPerson();
			String strTo = chatMessage.getChatPerson();
			String strToSession = chatMessage.getChatPersonSession();
			
			sendToOne(strToSession, strTo, strFrom, strMsg);
			
		}
	}

	private void sendBroadcast() {
		for (Session ses : room.getUserList()) {
			String strName = ses.getUserProperties().get("name").toString();
			String strSessionId = ses.getId();
			room.sendMessage(strName + "^join^" + strSessionId);
		}
	}
	private void sendToOne(String strCurSessionId,String strTo, String strFrom,String strMessage){
		
			String strMsg = "-^" + "msg^" + strFrom + "^" + strMessage;
			
			room.sendMessageToOne(strMsg, strCurSessionId);

	}

	@OnClose
	public void onClose(Session session, CloseReason reason) {
		String strSessionId = session.getId();
		room.leave(session);
		room.sendMessage((String) session.getUserProperties().get("name") + "^left^" + strSessionId);
	}

	@OnError
	public void onError(Session session, Throwable ex) {
		log.info("Error: " + ex.getMessage());
	}
}
